clear
L = 150E-9; %x direction
W = 100E-9; %y direction
Vo = 1;

nx = 20;
ny = 20;

V = zeros(nx,ny);
G = sparse(nx*ny,nx*ny);
F = zeros(nx*ny,1);

%case1 = 1; %question 1a) boundary conditions 
case1 = 0; %question 1b) boundary conditions


for i = 1:nx
    for j = 1:ny
        n = j + (i-1)*ny; %mapping equation
        
        if i == 1
                F(n) = Vo;
                G(n,n) = 1;
        elseif i == nx
            if case1 == 1
                F(n) = 0;
                G(n,n) = 1;
            else
                F(n) = Vo;
                G(n,n) = 1;
            end
        elseif j == 1
            if case1 == 1
                F(n) = 0;
                nxm = j + ((i-1)-1)*ny; %(i-1,j)
                nxp = j + ((i+1)-1)*ny; %(i+1,j)
                nyp = (j+1) + (i-1)*ny; %(i,j+1)
                G(n,n) = -3;
                G(n,nxm) = 1;
                G(n,nxp) = 1;
                G(n,nyp) = 1;
            else
                F(n) = 0;
                G(n,n) = 1;
            end
        elseif j == ny
            if case1 == 1
                F(n) = 0;
                nxm = j + ((i-1)-1)*ny; %(i-1,j)
                nxp = j + ((i+1)-1)*ny; %(i+1,j)
                nym = (j-1) + (i-1)*ny; %(i,j-1)
                G(n,n) = -3;
                G(n,nxm) = 1;
                G(n,nxp) = 1;
                G(n,nym) = 1;
            else
                F(n) = 0;
                G(n,n) = 1;
            end
            
        else
            nxm = j + ((i-1)-1)*ny; %(i-1,j)
            nxp = j + ((i+1)-1)*ny; %(i+1,j)
            nym = (j-1) + (i-1)*ny; %(i,j-1)
            nyp = (j+1) + (i-1)*ny; %(i,j+1)
            
            G(n,n) = -4;
            G(n,nxm) = 1;
            G(n,nxp) = 1;
            G(n,nym) = 1;
            G(n,nyp) = 1;
            
        end
    end
end

axis([0 L 0 W]);

M = G\F;
for i = 1:nx
    for j = 1:ny
        n = j + (i-1)*ny;
        V(i,j) = M(n);
    end
end

figure(1)
surf(V)
title('Surface Potential Plot (n = 20)')
xlabel('Y')
ylabel('X')
zlabel('V(x,y)')


[Ey, Ex] = gradient(V); %plotting gradient
    
figure(2)
quiver(-Ex',-Ey',10) %vector arrows
title('Electric Field Gradient (n = 20)')
xlabel('Y')
ylabel('X')


%Analytical Solution
Sum = zeros(nx,ny);
a = W;
b = L/2;
x = linspace(-b,b,nx);
y = linspace(0,a,ny);

[X,Y] = meshgrid(x,y);

for n = 1:300
    s = (-1).^n; %only counting on odd numbers
    if s == -1
        Vxy = ((4.*Vo)./pi).*(1./n).*(((cosh((n.*pi.*X)./a)).*(sin((n.*pi.*Y)./a)))./(cosh((n.*pi.*b)./a)));
    else
        Vxy = 0;
    end
    Sum = Sum + Vxy;
end
        

figure(3)
surf(Sum)
title('Analytical Series Solution (n = 20)')
xlabel('X')
ylabel('Y')
zlabel('V(x,y)')
zlim([0 1])


[Ey2, Ex2] = gradient(Sum); %plotting gradient
    
figure(4)
quiver(-Ex2',-Ey2',10) %vector arrows
title('Analytical Solution Electric Field Gradient (n = 20)')
xlabel('X')
ylabel('Y')
            
            