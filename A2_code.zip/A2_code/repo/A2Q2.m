clear
L = 150E-9; %x direction
W = 100E-9; %y direction

Vo = 1;

nx = 50;
ny = 50;

V = zeros(nx,ny);
C = zeros(nx,ny); %conductivity map
G = sparse(nx*ny,nx*ny);
F = zeros(nx*ny,1);
Cond = 1; %conductivity outside the boxes


%Part d)
%CondBox = 1;
%CondBox = 0.9;
%CondBox = 0.75;
%CondBox = 0.5;
%CondBox = 0.25;
CondBox = 10^-2; %conductivity inside the boxes
%CondBox = 10^-3;
%CondBox = 10^-4;



% Part c)
box1 = 1; %turning on regular box
box2 = 0; %turning on more narrow box
box3 = 0; %turning on most narrow box

if box1 == 1
b1 = rectangle('Position',[0.55E-7,0,0.4E-7,0.4E-7]); %box1 position (bottom)
b2 = rectangle('Position',[0.55E-7,0.6E-7,0.4E-7,0.4E-7]); %box2 position (top)
end

if box2 == 1
b1 = rectangle('Position',[0.55E-7,0,0.4E-7,0.45E-7]); %box1 position (bottom)
b2 = rectangle('Position',[0.55E-7,0.55E-7,0.4E-7,0.45E-7]); %box2 position (top)
end

if box3 == 1
b1 = rectangle('Position',[0.55E-7,0,0.4E-7,0.49E-7]); %box1 position (bottom)
b2 = rectangle('Position',[0.55E-7,0.51E-7,0.4E-7,0.49E-7]); %box2 position (top)
end


for i = 1:nx
    for j = 1:ny
        
        l = (L/nx)*i;
        w = (W/ny)*j;
        
        if l > 0.55E-7 && l < 0.95E-7 && (w > 0.6E-7 || w < 0.4E-7) && box1 == 1
            C(i,j) = CondBox;
        elseif l > 0.55E-7 && l < 0.95E-7 && (w > 0.55E-7 || w < 0.45E-7) && box2 == 1
            C(i,j) = CondBox;
        elseif l > 0.55E-7 && l < 0.95E-7 && (w > 0.51E-7 || w < 0.49E-7) && box3 == 1
            C(i,j) = CondBox;
        else
            C(i,j) = Cond;
        end
    end
end

case1 = 1; %keep equal to 1 for pt. 2

for i = 1:nx
    for j = 1:ny
        n = j + (i-1)*ny; %mapping equation

        if i == 1
                F(n) = Vo;
                G(n,n) = C(i,j);
        elseif i == nx
            if case1 == 1
                F(n) = 0;
                G(n,n) = C(i,j);
            else
                F(n) = Vo;
                G(n,n) = C(i,j);
            end
        elseif j == 1
            if case1 == 1
                F(n) = 0;
                nxm = j + ((i-1)-1)*ny; %(i-1,j)
                nxp = j + ((i+1)-1)*ny; %(i+1,j)
                nyp = (j+1) + (i-1)*ny; %(i,j+1)
                G(n,n) = -(C(i-1,j) + C(i+1,j) + C(i,j+1));
                G(n,nxm) = C(i-1,j);
                G(n,nxp) = C(i+1,j);
                G(n,nyp) = C(i,j+1);
            else
                F(n) = 0;
                G(n,n) = C(i,j);
            end
        elseif j == ny
            if case1 == 1
                F(n) = 0;
                nxm = j + ((i-1)-1)*ny; %(i-1,j)
                nxp = j + ((i+1)-1)*ny; %(i+1,j)
                nym = (j-1) + (i-1)*ny; %(i,j-1)
                G(n,n) = -(C(i-1,j) + C(i+1,j) + C(i,j-1));
                G(n,nxm) = C(i-1,j);
                G(n,nxp) = C(i+1,j);
                G(n,nym) = C(i,j-1);
            else
                F(n) = 0;
                G(n,n) = C(i,j);
            end
            
        else
            nxm = j + ((i-1)-1)*ny; %(i-1,j)
            nxp = j + ((i+1)-1)*ny; %(i+1,j)
            nym = (j-1) + (i-1)*ny; %(i,j-1)
            nyp = (j+1) + (i-1)*ny; %(i,j+1)
            
            G(n,n) = -(C(i-1,j) + C(i+1,j) + C(i,j-1) + C(i,j+1));
            G(n,nxm) = C(i-1,j);
            G(n,nxp) = C(i+1,j);
            G(n,nym) = C(i,j-1);
            G(n,nyp) = C(i,j+1);
            
        end
    end
end

axis([0 L 0 W]);

M = G\F;
for i = 1:nx
    for j = 1:ny
        n = j + (i-1)*ny;
        V(i,j) = M(n);
    end
end

figure(1) %conductivity map
surf(C)
title('Conductivity Plot')
xlabel('Y')
ylabel('X')
zlabel('Conductivity(x,y)')

figure(2) %potential map
surf(V)
title('Potential Plot')
xlabel('Y')
ylabel('X')
zlabel('V(x,y)')


%Electric Field
[Ey, Ex] = gradient(V); %plotting electric field gradient
    
figure(3)
quiver(-Ex',-Ey',10) %vector arrows
title('Electric Field Gradient')
xlabel('X')
ylabel('Y')


%Current Density
Jx = -C.*Ex;
Jy = -C.*Ey;

figure(4) %current density map
quiver(Jx',Jy',10) %vector arrows
title('Current Density (x,y)')
xlabel('X')
ylabel('Y')

figure(5) %current density plot in x
surf(Jx)
title('Current Density (x)')
xlabel('Y')
ylabel('X')
zlabel('J(x)')

figure(6) %current density plot in y
surf(Jy)
title('Current Density (y)')
xlabel('Y')
ylabel('X')
zlabel('J(y)')


%Current Left Edge
deltaY = W/ny;
SumIL = 0;

for j = 1:ny
    IL = (deltaY)*(Jx(1,j));
    SumIL = SumIL + IL;
end

figure(7)
plot(Jx(1,:))
title('Left Edge Current (x = 0)')
xlabel('Y')
ylabel('I(y)')

%Current Right Edge
deltaY = W/ny;
SumIR = 0;

for j = 1:ny
    IR = (deltaY)*(Jx(nx,j));
    SumIR = SumIR + IR;
end

figure(8)
plot(Jx(nx,:))
title('Right Edge Current (x = nx)')
xlabel('Y')
ylabel('I(y)')


%current vs. mesh size (CondBox = 10^-2, box1)
MeshSize = [5;10;50;100;200];
Current = [1.2010E-8;3.2612E-9;7.1002E-10;3.5052E-10;1.7648E-10];
T1 = table(MeshSize,Current);
figure(9)
plot(T1.MeshSize,T1.Current)
title('Current vs. Mesh Size')
xlabel('Mesh Size (n)')
ylabel('Current (A)')


%current vs. different bottlenecks (nx = 50, CondBox = 10^-2)
BottleNeck = [0.2E-7;0.1E-7;0.02E-7];
Current = [7.1002E-10;4.3635E-10;1.2181E-10];
T2 = table(BottleNeck,Current);
figure(10)
plot(T2.BottleNeck,T2.Current)
title('Current vs. Bottleneck Size')
xlabel('Bottleneck Size (m)')
ylabel('Current (A)')


%current vs. conductivity (nx = 50, box1)
ConductivityBox = [1;0.9;0.75;0.5;0.25;10^-2;10^-3;10^-4];
Current = [2.0408E-9;1.9471E-9;1.7766E-9;1.4002E-9;9.5442E-10;7.1002E-10;7.0931E-10;7.0928E-10];
T3 = table(ConductivityBox,Current);
figure(11)
plot(T3.ConductivityBox,T3.Current)
title('Current vs. Box Conductivity')
xlabel('Box Conductivity')
ylabel('Current (A)')
