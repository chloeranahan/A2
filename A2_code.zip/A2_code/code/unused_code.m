% V(i,j) = (V(i+1,j) + V(i-1,j))/2;
% 
% L = 300; %x direction
% W = 200; %y direction
% Vo = 1;
% 
% V = zeros(L,W);
% % G = sparse(L*W,L*W);
% 
% dV_dy = 0;
% 
% for i = 1:L
%     for j = 1:W
%         
%         if i == 1
%             V(i,j) = Vo;
%         elseif i == L
%             V(i,j) = 0;
%         else
%             V(i,j) = ;
%             
%         end
%     end
% end
% 
% spy(V)
% hold on

% G(:,W) = G(:,W-1);
% G(:,1) = G(:,2);

% spy(G)
% hold on
% 
% nmodes = 9;
% 
% [E,D] = eigs(G,nmodes,'SM');
% 
% np = sqrt(nmodes);

%         if i == 1
%             G(n,n) = 1;
%             F(n) = 1;
%             
%         elseif i == nx
%             G(n,n) = 0;
%             F(n) = 0;


% before changing case statements
% 
% L = 150E-9; %x direction
% W = 100E-9; %y direction
% Vo = 1;
% 
% nx = 20;
% ny = 20;
% 
% V = zeros(nx,ny);
% G = sparse(nx*ny,nx*ny);
% F = zeros(nx*ny,1);
% 
% case1 = 1; %question 1a) boundary conditions 
% %case1 = 0;
% 
% %case2 = 1; %question 1b) boundary conditions
% case2 = 0;
% 
% %dV_dy = 0;
% 
% for i = 1:nx
%     for j = 1:ny
%         n = j + (i-1)*ny; %mapping equation
%         
%         if i == 1
%             if case1 == 1 || case2 == 1
%                 F(n) = Vo;
%                 G(n,n) = 1;
%             end
%         elseif i == nx
%             if case1 == 1
%                 F(n) = 0;
%                 G(n,n) = 1;
%             elseif case2 == 1
%                 F(n) = Vo;
%                 G(n,n) = 1;
%             end
%         elseif j == 1
%             if case1 == 1
%                 F(n) = 0;
%                 nxm = j + ((i-1)-1)*ny; %(i-1,j)
%                 nxp = j + ((i+1)-1)*ny; %(i+1,j)
%                 nyp = (j+1) + (i-1)*ny; %(i,j+1)
%                 G(n,n) = -3;
%                 G(n,nxm) = 1;
%                 G(n,nxp) = 1;
%                 G(n,nyp) = 1;
%             elseif case2 == 1
%                 F(n) = 0;
%                 G(n,n) = 1;
%             end
%         elseif j == ny
%             if case1 == 1
%                 F(n) = 0;
%                 nxm = j + ((i-1)-1)*ny; %(i-1,j)
%                 nxp = j + ((i+1)-1)*ny; %(i+1,j)
%                 nym = (j-1) + (i-1)*ny; %(i,j-1)
%                 G(n,n) = -3;
%                 G(n,nxm) = 1;
%                 G(n,nxp) = 1;
%                 G(n,nym) = 1;
%             elseif case2 == 1
%                 F(n) = 0;
%                 G(n,n) = 1;
%             end
%             
%         else
%             nxm = j + ((i-1)-1)*ny; %(i-1,j)
%             nxp = j + ((i+1)-1)*ny; %(i+1,j)
%             nym = (j-1) + (i-1)*ny; %(i,j-1)
%             nyp = (j+1) + (i-1)*ny; %(i,j+1)
%             
%             G(n,n) = -4;
%             G(n,nxm) = 1;
%             G(n,nxp) = 1;
%             G(n,nym) = 1;
%             G(n,nyp) = 1;
%             
%         end
%     end
% end
% 
% axis([0 L 0 W]);
% 
% M = G\F;
% for i = 1:nx
%     for j = 1:ny
%         n = j + (i-1)*ny;
%         V(i,j) = M(n);
%     end
% end
% 
% figure(1)
% surf(V)
% 
% 
% [Ex, Ey] = gradient(V); %plotting gradient
%     
% figure(2)
% quiver(-Ey',-Ex',10) %vector arrows


% V2 = zeros(nx,ny);
% a = W;
% b = L/2;
% 
% for i = 1:nx
%     for j = 1:ny
%         n = j + (i-1)*ny; %mapping equation
%         for n = 1:1000
%             s = (-1).^n;
%             if s == -1
%             V2(i,j) = ((4.*Vo)./pi).*(1./n).*(((cosh((n.*pi.*i)./a)).*(sin((n.*pi.*j)./a)))./(cosh((n.*pi.*b)./a)));
%             else
%             V2(i,j) = 0;
%             end
%         end
%         
%     end
% end

%Current
% A = L.*W;
% I = J.*A;



% figure(9) %current vs. mesh size
% plot(SumIL,nx)
% xlabel('I')
% ylabel('nx')
% ylim([1 100]);
%plot I vs. 1/(delta)

% figure(10) %current vs. different bottlenecks
% if box1 == 1
%     SizeBN = 0.2E-7;
% elseif box2 == 1
%     SizeBN = 0.1E-7;
% elseif box3 == 1
%     SizeBN = 0.02E-7;
% end
% plot(I,SizeBN)
% xlabel('I')
% ylabel('SizeBN')
% 
% figure(11) %current vs. conductivity
% plot(I,C)
% xlabel('I')
% ylabel('C')